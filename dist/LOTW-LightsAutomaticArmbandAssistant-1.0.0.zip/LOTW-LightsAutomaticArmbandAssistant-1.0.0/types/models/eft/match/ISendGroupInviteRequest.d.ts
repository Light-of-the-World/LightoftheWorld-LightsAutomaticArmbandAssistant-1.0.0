export interface ISendGroupInviteRequest {
    to: string;
    inLobby: boolean;
}
