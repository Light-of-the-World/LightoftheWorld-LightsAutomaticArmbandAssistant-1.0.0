export declare enum ItemAddedResult {
    SUCCESS = 1,
    NO_SPACE = 2
}
