export interface IBaseRepairActionDataRequest {
    Action: string;
}
