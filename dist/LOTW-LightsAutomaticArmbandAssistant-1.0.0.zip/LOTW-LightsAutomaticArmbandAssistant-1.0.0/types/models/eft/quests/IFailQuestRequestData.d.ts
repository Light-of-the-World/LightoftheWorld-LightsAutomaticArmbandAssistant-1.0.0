export interface IFailQuestRequestData {
    Action: "QuestComplete";
    qid: string;
    removeExcessItems: boolean;
}
