import { IBotBase } from "./tables/IBotBase";
export interface IPmcData extends IBotBase {
}
