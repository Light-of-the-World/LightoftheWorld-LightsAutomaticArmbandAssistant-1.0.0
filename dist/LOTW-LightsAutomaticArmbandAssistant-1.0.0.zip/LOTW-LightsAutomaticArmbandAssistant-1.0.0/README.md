Drewgamer's original readme (any edits will be in (), usually with "LOTW" before it):
"​Fin's AI Tweaks​ had a feature that gave enemy bots an armband based on the type of bot they were (Scav, PMC, Boss/Follower, ect).
​I thought it was a pretty nice feature (especially when running as a Scav to better spot other Scavs) so I wanted to attempt to recreate it for myself (since it looks like FAIT is no longer being developed).
​
​This is the result.
​
​Pretty basic/barebones type mod, though does come with a config with a few changeable options.
​Currently supported bot-types are: Scav (includes snipers and cursed), Raiders, Rogues, USEC, BEAR, (LOTW: Bloodhounds), and Bosses (includes all their followers and cultists)
​Currently supported arm-bands are: blue, green, red, white, yellow, and purple (Twitch2020) (LOTW: Might add more post-release!)
​
## **​​Installation:**
​Extract the "(Lightoftheworld-LightsAutomaticArmbandAssistant)" folder to your "\SPT\user\mods\" folder.​


## **​Uninstallation:**
​Delete the "(Lightoftheworld-LightsAutomaticArmbandAssistant)" folder from your "\SPT\user\mods\" folder.


## **​Thanks/Credits:**
Fin for the original idea.
​All the great modders hanging out in the SPT Discord server (including, but not limited Lua and Chomp)."

LOTW- Special thanks to Dirtbikercj and Refringe for helping me learn how to fix this mod! And, obviously, thanks to Drewgamer for making this mod in the first place, full credits to them!