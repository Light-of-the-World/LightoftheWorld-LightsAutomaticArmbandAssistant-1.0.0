export interface IHandbookCallbacks {
    load(): void;
}
