export declare class Program {
    private errorHandler;
    constructor();
    start(): void;
}
