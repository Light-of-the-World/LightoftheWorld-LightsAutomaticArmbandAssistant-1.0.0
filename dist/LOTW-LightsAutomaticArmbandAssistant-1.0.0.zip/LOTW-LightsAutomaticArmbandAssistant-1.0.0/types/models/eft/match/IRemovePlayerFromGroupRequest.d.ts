export interface IRemovePlayerFromGroupRequest {
    aidToKick: string;
}
