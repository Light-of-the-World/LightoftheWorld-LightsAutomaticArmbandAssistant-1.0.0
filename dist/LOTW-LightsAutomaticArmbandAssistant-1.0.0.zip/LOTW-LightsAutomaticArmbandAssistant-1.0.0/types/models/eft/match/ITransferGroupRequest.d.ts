export interface ITransferGroupRequest {
    aidToChange: string;
}
