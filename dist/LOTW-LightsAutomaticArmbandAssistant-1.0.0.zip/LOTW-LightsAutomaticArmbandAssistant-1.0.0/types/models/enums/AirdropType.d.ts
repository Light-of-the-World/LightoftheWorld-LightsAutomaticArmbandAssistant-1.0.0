export declare enum AirdropTypeEnum {
    MIXED = "mixed",
    WEAPONARMOR = "weaponarmor",
    FOODMEDICAL = "foodmedical",
    BARTER = "barter"
}
