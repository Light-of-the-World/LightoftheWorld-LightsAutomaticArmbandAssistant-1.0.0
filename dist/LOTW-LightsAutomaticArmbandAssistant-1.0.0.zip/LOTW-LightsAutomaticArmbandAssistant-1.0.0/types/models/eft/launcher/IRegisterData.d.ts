import { ILoginRequestData } from "./ILoginRequestData";
export interface IRegisterData extends ILoginRequestData {
    edition: string;
}
