export interface IWorkoutData extends Record<string, any> {
    skills: any;
    effects: any;
}
