export interface IGetProfileSettingsRequest {
    squadInviteRestriction: boolean;
}
