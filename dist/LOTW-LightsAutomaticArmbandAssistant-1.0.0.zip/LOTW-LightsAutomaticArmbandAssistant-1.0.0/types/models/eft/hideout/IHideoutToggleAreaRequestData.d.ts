export interface IHideoutToggleAreaRequestData {
    Action: "HideoutToggleArea";
    areaType: number;
    enabled: boolean;
    timestamp: number;
}
