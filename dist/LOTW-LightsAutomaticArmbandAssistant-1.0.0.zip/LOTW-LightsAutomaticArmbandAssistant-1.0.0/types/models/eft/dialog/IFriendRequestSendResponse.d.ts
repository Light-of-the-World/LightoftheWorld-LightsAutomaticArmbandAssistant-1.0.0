export interface IFriendRequestSendResponse {
    status: number;
    requestid: string;
    retryAfter: number;
}
