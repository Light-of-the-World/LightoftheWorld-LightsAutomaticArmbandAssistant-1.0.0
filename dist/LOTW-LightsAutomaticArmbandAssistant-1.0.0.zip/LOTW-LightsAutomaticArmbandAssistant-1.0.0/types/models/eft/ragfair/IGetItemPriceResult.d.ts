import { MinMax } from "../../../models/common/MinMax";
export interface IGetItemPriceResult extends MinMax {
    avg: number;
}
