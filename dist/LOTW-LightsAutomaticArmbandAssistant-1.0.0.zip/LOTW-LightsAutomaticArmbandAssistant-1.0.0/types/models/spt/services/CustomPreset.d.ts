import { IPreset } from "../../eft/common/IGlobals";
export interface CustomPreset {
    key: string;
    preset: IPreset;
}
