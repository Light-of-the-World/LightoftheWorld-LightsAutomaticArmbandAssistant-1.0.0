export declare class UtilityHelper {
    arrayIntersect<T>(a: T[], b: T[]): T[];
}
