export interface IGetSuitsResponse {
    _id: string;
    suites: string[];
}
