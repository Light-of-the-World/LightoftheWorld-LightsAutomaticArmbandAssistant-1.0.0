import { LootItem } from "../../../models/spt/services/LootItem";
export interface IAirdropLootResult {
    dropType: string;
    loot: LootItem[];
}
