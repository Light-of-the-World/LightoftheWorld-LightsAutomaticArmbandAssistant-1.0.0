export interface Ixyz {
    x: number;
    y: number;
    z: number;
}
