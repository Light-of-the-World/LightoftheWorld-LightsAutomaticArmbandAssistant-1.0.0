export interface IAcceptGroupInviteRequest {
    requestId: string;
}
