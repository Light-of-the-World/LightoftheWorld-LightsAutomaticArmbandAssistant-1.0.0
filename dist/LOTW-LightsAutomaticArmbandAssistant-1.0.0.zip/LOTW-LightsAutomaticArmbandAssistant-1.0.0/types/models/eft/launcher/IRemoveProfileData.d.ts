import { ILoginRequestData } from "./ILoginRequestData";
export type IRemoveProfileData = ILoginRequestData;
