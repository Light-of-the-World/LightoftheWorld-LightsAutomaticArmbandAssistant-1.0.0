export interface IRemoveMailMessageRequest {
    dialogId: string;
}
