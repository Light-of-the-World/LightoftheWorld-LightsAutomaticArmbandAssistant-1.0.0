export declare enum GiftSenderType {
    SYSTEM = "System",
    TRADER = "Trader",
    USER = "User"
}
