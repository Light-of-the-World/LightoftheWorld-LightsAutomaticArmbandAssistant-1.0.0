export interface IRecordShootingRangePoints {
    Action: "RecordShootingRangePoints";
    points: number;
}
