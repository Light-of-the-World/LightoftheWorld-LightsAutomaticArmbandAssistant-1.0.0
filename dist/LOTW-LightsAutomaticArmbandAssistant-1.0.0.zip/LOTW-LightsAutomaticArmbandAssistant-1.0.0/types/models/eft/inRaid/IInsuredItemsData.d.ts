export interface IInsuredItemsData {
    id: string;
    durability?: number;
    maxDurability?: number;
    hits?: number;
}
