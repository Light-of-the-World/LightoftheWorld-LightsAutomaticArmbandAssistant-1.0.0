export interface ICancelGroupInviteRequest {
    requestId: string;
}
