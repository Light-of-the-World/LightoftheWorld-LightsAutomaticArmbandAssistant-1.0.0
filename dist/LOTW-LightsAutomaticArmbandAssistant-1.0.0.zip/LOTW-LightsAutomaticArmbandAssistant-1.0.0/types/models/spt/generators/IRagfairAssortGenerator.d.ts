import { Item } from "../../eft/common/tables/IItem";
export interface IRagfairAssortGenerator {
    getAssortItems(): Item[];
}
